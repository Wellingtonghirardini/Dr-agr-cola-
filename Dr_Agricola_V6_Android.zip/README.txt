DR. AGRÍCOLA V6 — PROJETO ANDROID

A imagem principal do assistente fornecida pelo usuário está em:
app/src/main/assets/assistente_branco_billy.jpg

O aplicativo usa essa imagem:
- no cabeçalho;
- na tela principal;
- no chat.

O projeto é uma base Android com WebView e permissões para câmera/microfone.
Para gerar o APK:
1. Abra a pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Build > Build APK(s).
4. O APK será gerado em app/build/outputs/apk/debug/.

IMPORTANTE:
Esta V6 é a estrutura Android. O chat visual está pronto, mas a conexão
com o servidor da IA deve apontar para o backend seguro da V5.1.
A chave da OpenAI não deve ficar dentro do APK.
